setwd("C:/Users/it24101003/Desktop/IT24101003")
# Q1
data<- read.table("Lab 04-20250822/Exercise.txt",header = TRUE, sep = ",")
fix(data)
attach(data)
head(data)

#Q2
str(data)
summary(data)

#Q3
X11()
boxplot(Sales_X1, main = "Boxplot for sale", ylab = "Sales")

#Q4
fivenum(Advertising_X2)
IQR(Advertising_X2)


#Q5
findOutlier <- function(x){
  q1<- quantile(x,0.25)
  q3<- quantile(x,0.75)
  IQRVal <- q3-q1
  lowerBound<- q1-1.5*IQRVal
  upperBound<- q3+1.5*IQRVal
  outlier <- x[x< lowerBound | x> upperBound]
  return(outlier)
}
outliersYears <- findOutlier(Years_X3)
outliersYears
